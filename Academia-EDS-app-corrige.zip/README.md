# Academia EDS – Application mobile

## 0. Base de données (une seule fois)
Supabase → SQL Editor → coller `supabase.sql` → Run. Le site et l'application se synchronisent ensuite tout seuls.

## Android (APK installable)
1. Crée un dépôt GitHub, envoie-y tout ce dossier (branche `main`).
2. Onglet **Actions** → « Android APK » → attends la fin (≈ 6 min).
3. Télécharge l'artefact **Academia-EDS-apk**, décompresse, installe `app-debug.apk` (autoriser les sources inconnues).

## iPhone + tous les téléphones (application web installable)
1. Dépôt GitHub → **Settings → Pages → Source : GitHub Actions**.
2. L'action « Web app » publie l'application à `https://TON-COMPTE.github.io/TON-DEPOT/`.
3. iPhone : ouvrir le lien dans **Safari** → Partager → **Sur l'écran d'accueil**. Android/PC : « Installer l'application ».

## Un vrai fichier iPhone (.ipa)
Impose un compte Apple Developer (99 $/an) et un Mac/Xcode : `npm install && npx cap add ios && npx cap open ios`.

## Où modifier
- `www/index.html` : interface de l'application (accueil, réglages, cloche, sons, thèmes, langues)
- `www/espace.html` : ton site complet (espace étudiant / admin / messagerie)
